# 📅 Persian Date Stamper PWA

یک اپلیکیشن وب پیشرفته (PWA) برای افزودن مُهر تاریخ شمسی روی عکس‌ها.

## ✨ ویژگی‌ها

- 📷 **عکس‌برداری مستقیم** از دوربین دستگاه
- 🖼️ **انتخاب عکس از گالری**
- 📅 **افزودن تاریخ شمسی** به صورت خودکار
- 🎨 **فیلترهای تصویری** (Dehaze, Clarity, Saturation)
- 📤 **اشتراک‌گذاری** آسان در شبکه‌های اجتماعی
- 💾 **ذخیره‌سازی محلی** با Service Worker
- 📱 **نصب روی صفحه اصلی** (Add to Home Screen)
- 🌐 **کاملاً آفلاین** بعد از اولین بارگذاری

## 🚀 نصب و استفاده

### روش 1: استفاده آنلاین
1. به آدرس زیر بروید:
   ```
   https://YOUR-USERNAME.github.io/persian-date-stamper-v2/
   ```
2. روی دکمه "Add to Home Screen" کلیک کنید
3. از اپلیکیشن مانند یک اپ نیتیو استفاده کنید!

### روش 2: اجرای محلی
```bash
# کلون کردن پروژه
git clone https://github.com/YOUR-USERNAME/persian-date-stamper-v2.git

# باز کردن در مرورگر
cd persian-date-stamper-v2
# فایل index.html را با مرورگر باز کنید
```

## 📱 پشتیبانی از پلتفرم‌ها

- ✅ Android (Chrome, Samsung Internet, Edge)
- ✅ iOS/iPhone (Safari)
- ✅ Desktop (تمام مرورگرهای مدرن)

## 🛠️ ساخته شده با

- HTML5 Canvas
- Vanilla JavaScript (بدون فریمورک!)
- Service Worker API
- Web Share API
- فونت Vazir

## 👨‍💻 توسعه‌دهنده

**K. Ghaleh**

## 📄 مجوز

این پروژه تحت مجوز MIT منتشر شده است.

---

### نکات تکنیکی:

- تصاویر در رزولوشن کامل (Full Resolution) پردازش می‌شوند
- فیلترهای تصویری به صورت Real-time اعمال می‌شوند
- Cache Invalidation هوشمند بعد از Share/Download
- فونت فارسی Vazir برای نمایش زیبای تاریخ
